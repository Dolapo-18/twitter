const posts = document.querySelector("#posts");

const createPost = post => {
	const div = `<div class="card">
						<div class="card-body">
							<p class="card-text">
								${post}
							</p>
							<div class="d-flex flex-row justify-content-between">
								<button class="btn btn-blue">Like</button>
								<button class="btn btn-danger">Delete</button>
							</div>
						</div>
					</div>`;
	return div;
};
const addPosts = event => {
	let divs = "";
	const token = getToken();
	axios.get("http://localhost:5000/api/notes/all").then(res =>
		res.data.forEach(datum => {
			const div = createPost(datum);
			divs += div;
		})

		posts.innerHTML = divs
	).catch((e) => console.log(e));
};

window.addEventListener("DOMContentLoaded", addPosts);
